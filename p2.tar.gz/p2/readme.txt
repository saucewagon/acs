Alexander Steel
V00855144

CSC 360 Assignment 2: ACS

Usage:

	% make
	% ./ACS customers.txt
